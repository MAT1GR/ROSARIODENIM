"use strict";
// mat1gr/rosariodenim/ROSARIODENIM-0a9e948297937bd8aefc1890579b3a59f99d6fdc/src/types/index.ts
Object.defineProperty(exports, "__esModule", { value: true });
